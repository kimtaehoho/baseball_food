import os
import sys
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from baseball_database_setup import Base, User as UserModel, Post
from werkzeug.utils import secure_filename


app = Flask(__name__)
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)),'static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
engine = create_engine('mysql+pymysql://root:root@localhost/baseball_db')
Base.metadata.bind = engine
DBSession = sessionmaker(bind=engine)
db_session = DBSession()
app.secret_key = 'asdsadadasdamsasdklfaskdl'


@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = db_session.query(UserModel).filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.user_id
            session['username'] = user.username
            return render_template('main.html', username=username, user_id=int(user.user_id))
        else:
            return render_template('login.html', message="로그인 실패. 다시 시도하세요.")
        
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            return render_template('signup.html', message="비밀번호가 일치하지 않습니다. 다시 시도하세요.")
        
        try:
            hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
            new_user = UserModel(username=username, password=hashed_password, email=email)
            db_session.add(new_user)
            db_session.commit()
            return redirect(url_for('login'))
        except Exception as e:
            db_session.rollback()
            return f"회원가입 중 오류가 발생했습니다: {str(e)}"
    
    return render_template('signup.html')


@app.route('/all')
def all():
    post = db_session.query(Post).all()

    if post:
        if 'username' in session and 'user_id' in session:
            username = session['username']
            user_id = session['user_id']
            return render_template('main.html', username=username, user_id=user_id, post=post)
    
    else : 
        return render_template('main.html', post=post, message="현재 작성된 게시물이 없습니다.")
    return render_template('main.html', post=post, message="현재 작성된 게시물이 없습니다.")



@app.route('/<string:location>')
def goToLocation(location):
    post = db_session.query(Post).filter(Post.location==location)

    if post:
        if 'username' in session and 'user_id' in session:
            username = session['username']
            user_id = session['user_id']
            return render_template('main.html', username=username, user_id=user_id, post=post)
    
    else : 
        return render_template('main.html', post=post, message="현재 작성된 게시물이 없습니다.")
    return render_template('main.html', post=post, message="현재 작성된 게시물이 없습니다.")


@app.route('/<string:post_id>',
           methods=['POST'])
def likeAction(post_id):
    thisPost = db_session.query(Post).filter_by(post_id=post_id).one()
    if request.method == 'POST':
        if thisPost.like_count==0:
            thisPost.like_count = 1
        elif thisPost.like_count==1:
            thisPost.like_count = 0
        db_session.add(thisPost)
        db_session.commit()
        return redirect(request.referrer)
    
@app.route('/main', methods=['POST'])
def main():
    if 'username' in session and 'user_id' in session:
        username = session['username']
        user_id = session['user_id']
        return render_template('write.html', username=username, user_id=user_id)
    else:
        return render_template('login.html', message="현재 로그인되어있지 않은 상태입니다.")
    


@app.route('/post', methods=['POST'])
def create_post():
    if 'username' in session and 'user_id' in session:
        username = session['username']
        user_id = session['user_id']
    else:
        return render_template('login.html', message = "현재 로그인되어있지 않은 상태입니다.")
    
    new_post = Post(user_id=user_id, username=username, title=request.form['title'], location=request.form['mapOptions'],
                     place=request.form['place'],main_dish=request.form['main_dish'],content=request.form['content'],
                     like_count = 0, image_exist=0)
    

    file = request.files['file']
    if file.filename == '':
        db_session.add(new_post)
        db_session.commit()

    if file:
        new_post = Post(user_id=user_id, username=username, title=request.form['title'], location=request.form['mapOptions'],
                     place=request.form['place'],main_dish=request.form['main_dish'],content=request.form['content'],
                     like_count = 0, image_exist=1)
        db_session.add(new_post)
        db_session.commit()
        latest_post = db_session.query(Post).order_by(Post.post_id.desc()).first()
        fileattribute = secure_filename(file.filename)
        fileattribute = fileattribute[-4:]
        filename = str(latest_post.post_id) + fileattribute
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

    return render_template('main.html')

@app.route('/movemypage', methods=['POST'])
def movemypage():
    if 'username' in session and 'user_id' in session:
        username = session['username']
        user_id = session['user_id']
        return render_template('mypage.html', username=username, user_id=user_id)
    else:
        return render_template('login.html', message="현재 로그인되어있지 않은 상태입니다.")
    
@app.route('/mypage')
def mypage():
    user_id = session['user_id']
    my_posts = db_session.query(Post).filter(Post.user_id == user_id).all()
    liked_posts = db_session.query(Post).filter(Post.user_id == user_id, Post.like_count == 1).all()

    my_posts_data = [
        {
            'post_id': post.post_id,
            'title': post.title,
            'location': post.location,
            'place': post.place,
            'main_dish': post.main_dish,
            'content': post.content,
            'image_exist': post.image_exist  
        } for post in my_posts
    ]

    liked_posts_data = [
        {
            'post_id': post.post_id,
            'title': post.title,
            'location': post.location,
            'place': post.place,
            'main_dish': post.main_dish,
            'content': post.content,
            'image_exist': post.image_exist  
        } for post in liked_posts
    ]

    return jsonify({
        'success': True,
        'my_posts': my_posts_data,
        'liked_posts': liked_posts_data
    })



@app.route('/delete_post/<int:post_id>', methods=['POST'])
def delete_post(post_id):
    post = db_session.query(Post).filter_by(post_id=post_id).first()

    try:
        db_session.delete(post)
        db_session.commit()
        return jsonify({'success': True})
    except Exception as e:
        print(e)
        return jsonify({'success': False})


@app.route('/editpage', methods=['GET', 'POST'])
def editpage():
    user_id = session['user_id']
    username = session['username']
    post_id = request.form.get('post_id')
    post = db_session.query(Post).filter_by(post_id=post_id).first()
    return render_template('edit.html', post=post, post_id=post_id, user_id=user_id,username=username)



@app.route('/edit', methods=['GET', 'POST'])
def edit():
    if 'username' in session and 'user_id' in session:
        user_id = session['user_id']
        username = session['username']

    if request.method == 'POST':
        post_id = request.form.get('post_id')
        post = db_session.query(Post).filter_by(post_id=post_id).first()
        if post:
            post.title = request.form.get('title')
            post.location = request.form.get('mapOptions')
            post.place = request.form.get('place')
            post.main_dish = request.form.get('main_dish')
            post.content = request.form.get('content')
            db_session.commit()

    return render_template('main.html', user_id=user_id,username=username)



if __name__ == '__main__':
    Base.metadata.create_all(engine)
    app.run(debug=True)
