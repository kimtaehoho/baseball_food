
DROP DATABASE IF EXISTS baseball_db;
CREATE DATABASE baseball_db default CHARACTER SET UTF8MB4;
USE baseball_db;

drop table IF EXISTS user;

CREATE TABLE user (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL
) ENGINE=INNODB;

drop table IF EXISTS post;

CREATE TABLE post (
  post_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  title VARCHAR(50) NOT NULL,
  location VARCHAR(50) NOT NULL,
  place VARCHAR(50) NOT NULL,
  main_dish VARCHAR(400) NOT NULL
) ENGINE=INNODB;

drop table IF EXISTS post_like;

select * from post;

CREATE TABLE post_like (
  like_id INT AUTO_INCREMENT PRIMARY KEY,
  post_id INT,
  user_id INT,
  FOREIGN KEY (post_id) REFERENCES post(post_id),
  FOREIGN KEY (user_id) REFERENCES user(user_id)
) ENGINE=INNODB;

INSERT INTO post VALUES(0, 'aaa','통밥', '잠실', '3루 2층', '김치말이국수 ・ 삼겹살 도시락');
INSERT INTO post VALUES(1, 'aaa', '와팡', '잠실', '1,3루 내야', '와플 아이스크림');
INSERT INTO post VALUES(2, 'aaa', '이가네떡볶이', '잠실', '3루 게이트', '떡볶이');
INSERT INTO post VALUES(3, 'aaa', '허갈닭강정', '문학', '1 게이트', '닭강정');
INSERT INTO post VALUES(4, 'aaa', '와인샵', '문학', '1루 1층', '나쵸');
INSERT INTO post VALUES(5, 'aaa', '버거트레일러', '문학', '1루 1층', '치즈 푸틴');
INSERT INTO post VALUES(6, 'aaa', '보영만두', '수원', '3루', '쫄면 ・ 만두');
INSERT INTO post VALUES(7, 'aaa', '진미통닭', '수원', '3루', '치킨');

COMMIT;
