
DROP DATABASE IF EXISTS baseball_db;
CREATE DATABASE baseball_db default CHARACTER SET UTF8MB4;
USE baseball_db;

drop table IF EXISTS user;

CREATE TABLE user (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL
) ENGINE=INNODB;

drop table IF EXISTS post;

CREATE TABLE post (
  post_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  title VARCHAR(50) NOT NULL,
  content VARChAR(4000) NOT NULL,
  create_time TIMESTAMP(6) NOT NULL,
  update_time TIMESTAMP(6) NOT NULL
) ENGINE=INNODB;

drop table IF EXISTS post_like;

CREATE TABLE post_like (
  like_id INT AUTO_INCREMENT PRIMARY KEY,
  post_id INT,
  user_id INT,
  FOREIGN KEY (post_id) REFERENCES post(post_id),
  FOREIGN KEY (user_id) REFERENCES user(user_id)
) ENGINE=INNODB;


COMMIT;
